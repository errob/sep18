//------------------------------------------------------------------------------
// CommandManager.cpp
//
// Group: Group 18622, study assistant Roman Walch
//
// Authors: Christina Dionysio (01610877)
// Johannes Mayerhofer (11739820)
// Robert Ertl (01114419)
//------------------------------------------------------------------------------

#include "CommandManager.h"

using Sep::CommandManager;

//------------------------------------------------------------------------------
CommandManager::CommandManager(Interface &io, Game &game)
												: game_(game), io_(io)
{
}

//------------------------------------------------------------------------------
CommandManager::~CommandManager()
{
}

//------------------------------------------------------------------------------
void CommandManager::start()
{
	std::string input;
	while (true)
	{
		input = io_.in();
		std::transform(input.begin(), input.end(), input.begin(), ::tolower);
		std::istringstream inputStream(input);
		std::vector<std::string>
			cmd{ std::istream_iterator<std::string>{inputStream},
						std::istream_iterator<std::string>{} };
		if (cmd.empty())
		{
			continue;
		}
		else if (cmd[0] == Interface::COMMAND_BUILD)
		{
			cmd_ = std::unique_ptr<Command>(new CommandBuild(cmd[0]));
		}
		else if (cmd[0] == Interface::COMMAND_DESTROY)
		{
			cmd_ = std::unique_ptr<Command>(new CommandDestroy(cmd[0]));
		}
		else if (cmd[0] == Interface::COMMAND_QUIT)
		{
			cmd_ = std::unique_ptr<Command>(new CommandQuit(cmd[0]));
		}
		else
		{
			io_.out(Interface::WARNING, Interface::WARNING_UNKNOWN_COMMAND);
			continue;
		}

		cmd.erase(cmd.begin());
		if (!cmd_->execute(game_, cmd))
		{
			io_.out(Interface::WARNING, Interface::WARNING_WRONG_PARAMETER);
			continue;
		}

		if (cmd_->getName() == Interface::COMMAND_QUIT)
		{
			break;
		}
	}
}