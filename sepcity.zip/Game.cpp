//------------------------------------------------------------------------------
// Game.cpp
//
// Group: Group 18622, study assistant Roman Walch
//
// Authors: Christina Dionysio (01610877)
// Johannes Mayerhofer (11739820)
// Robert Ertl (01114419)
//------------------------------------------------------------------------------
//

#include "Game.h"
#include "ConfigFile.h"

using Sep::Game;

//------------------------------------------------------------------------------
const std::shared_ptr<Sep::Field> Game::GRASSPTR =
	    std::shared_ptr<Field>(new Grass());

//------------------------------------------------------------------------------
const std::shared_ptr<Sep::Field> Game::OBSTACLEPTR =
      std::shared_ptr<Field>(new Obstacle());

//------------------------------------------------------------------------------
const std::shared_ptr<Sep::Field> Game::WATERPTR =
      std::shared_ptr<Field>(new Water());

//------------------------------------------------------------------------------
Game::Game(Interface &io, std::string config) : io_(io), config_(config)
{
  ConfigFile config_file(config_, *this);
  if(!config_file.openFile())
  {
    throw std::invalid_argument (Sep::Interface::ERROR_INVALID_CONFIG);
  }

  io_.out(Interface::SETTING, "BOARDSIZE " + std::to_string(board_width_)
    + " " + std::to_string(board_height_));
}

//------------------------------------------------------------------------------
Game::~Game() noexcept
{
}

//------------------------------------------------------------------------------
int Game::getWidth()
{
  return board_width_;
}

//------------------------------------------------------------------------------
int Game::getHeight()
{
  return board_height_;
}

//------------------------------------------------------------------------------
int Game::getMoney()
{
  return money_;
}

//------------------------------------------------------------------------------
std::vector<std::vector<std::shared_ptr<Sep::Field>>> Game::getMap()
{
  return map_;
}

//------------------------------------------------------------------------------
void Game::setWidth(const int width)
{
  board_width_ = width;
}

//------------------------------------------------------------------------------
void Game::setHeight(const int height)
{
  board_height_ = height;
}

//------------------------------------------------------------------------------
void Game::setMoney(const int money)
{
  money_ = money;
}

//------------------------------------------------------------------------------
void Game::setMap(const std::vector<std::shared_ptr<Field>> column_vec)
{
  map_.push_back(column_vec);
}

//------------------------------------------------------------------------------
void Game::run()
{
	io_.out(Interface::MONEY, std::to_string(money_));
  printMap();
}

//------------------------------------------------------------------------------
void Game::build(Field::FieldType fieldType, int x, int y)
{
  std::shared_ptr<Field> field = nullptr;
  if (fieldType == Field::FieldType::OBSTACLE)
  {
    field = std::shared_ptr<Field>(new Obstacle());
  }
  else if (fieldType == Field::FieldType::STREET)
  {
    field = std::shared_ptr<Field>(new Street());
  }
  else if (fieldType == Field::FieldType::WATER)
  {
    field = std::shared_ptr<Field>(new Water());
  }
  if (setField(field, x, y))
  {
    io_.out(Interface::MONEY, std::to_string(money_));
    printMap();
  }
}

//------------------------------------------------------------------------------
void Game::build(Field::FieldType fieldType, int x, int y,
                                             int width, int height)
{
  std::shared_ptr<Field> field = nullptr;
  if (fieldType == Field::FieldType::CLINIC)
  {
    field = std::shared_ptr<Field>(new Clinic(x, y, width, height));
  }
  else if (fieldType == Field::FieldType::HOME)
  {
    field = std::shared_ptr<Field>(new Home(x, y, width, height));
  }
  else if (fieldType == Field::FieldType::MARKET)
  {
    field = std::shared_ptr<Field>(new Market(x, y, width, height));
  }
  if (setField(field, x, y, width, height, true))
  {
    io_.out(Interface::MONEY, std::to_string(money_));
    printMap();
  }
}

//------------------------------------------------------------------------------
void Game::destroy(int x, int y)
{
  if (x >= board_width_ || x < 0 || y >= board_height_ || y < 0)
  {
    io_.out(Interface::INFO, Interface::INFO_OUTSIDE_BOARD);
    return;
  }
  if (!(*map_.at(y).at(x)).isDestroyable())
  {
    io_.out(Interface::INFO, Interface::INFO_CANNOT_DESTROY);
    return;
  }
  if ((*map_.at(y).at(x)).getDestroyCost() > money_)
  {
    io_.out(Interface::INFO, Interface::INFO_NOT_ENOUGH_MONEY);
    return;
  }
	money_ -= (*map_.at(y).at(x)).getDestroyCost();
  if ((*map_.at(y).at(x)).getSize() > 1)
  {
    std::shared_ptr<Building> obj =
    std::dynamic_pointer_cast<Building>(map_.at(y).at(x));

    int posX = obj->getPosX();
    int posY = obj->getPosY();
    int width = obj->getWidth();
    int height = obj->getHeight();
    for (int col = 0; col < width; col++)
    {
      for (int row = 0; row < height; row++)
      {
        map_.at(posY + row).at(posX + col) = GRASSPTR;
      }
    }
  }
  else
  {
    map_.at(y).at(x) = GRASSPTR;
  }
  io_.out(Interface::MONEY, std::to_string(money_));
  printMap();
}

//------------------------------------------------------------------------------
void Game::quit()
{
  io_.out(Interface::INFO, Interface::INFO_QUIT_MSG);
  money_ = 0;
  io_.out(Interface::MONEY, std::to_string(money_));
  printMap();
}

//------------------------------------------------------------------------------
bool Game::setField(std::shared_ptr<Field> field, int x, int y, int width,
                    int height, bool is_building)
{
  if (field == nullptr)
  {
    return false;
  }
  if (x + width - 1 >= board_width_ || x < 0 || y + height - 1 >=
                       board_height_ || y < 0)
  {
    io_.out(Interface::INFO, Interface::INFO_OUTSIDE_BOARD);
    return false;
  }
  for (int col = 0; col < width; col++)
  {
    for (int row = 0; row < height; row++)
    {
      if ((*map_.at(y + row).at(x + col)).getType() != Field::FieldType::GRASS)
      {
        io_.out(Interface::INFO, Interface::INFO_GRASS_ONLY);
        return false;
      }
    }
  }
  if (width > 3 || height > 3)
  {
    io_.out(Interface::INFO, Interface::INFO_MAX_SIZE);
    return false;
  }
  if (is_building)
  {
    if (hasNeighbour(x, y, width, height))
    {
      io_.out(Interface::INFO, Interface::INFO_SPACING);
      return false;
    }
  }
  if (field->getBuildCost() > money_)
  {
    io_.out(Interface::INFO, Interface::INFO_NOT_ENOUGH_MONEY);
    return false;
  }
	money_ -= field->getBuildCost();
  for (int col = 0; col < width; col++)
  {
    for (int row = 0; row < height; row++)
    {
      map_.at(y + row).at(x + col) = field;
    }
  }
  return true;
}

//------------------------------------------------------------------------------
bool Game::hasNeighbour(int x, int y, int width, int height)
{
  int colMin = x == 0 ? 0 : x - 1;
  int colMax = x + width == board_width_ ? board_width_ : x + width + 1;
  int rowMin = y == 0 ? 0 : y - 1;
  int rowMax = y + height == board_height_ ? board_height_ : y + height + 1;
  for (int row = rowMin; row < rowMax; row++)
  {
    for (int col = colMin; col < colMax; col++)
    {
      if (std::dynamic_pointer_cast<Building>(map_.at(row).at(col)) != nullptr)
      {
        return true;
      }
    }
  }
  return false;
}

//------------------------------------------------------------------------------
void Game::printMap()
{
  std::vector<std::vector<Field::FieldType>> map;
  for (auto row = 0; row < board_width_; row++)
  {
    std::vector<Field::FieldType> vector_column;
    for (auto column = 0; column < board_height_; column++)
    {
      vector_column.push_back((*map_.at(column).at(row)).getType());
    }
    map.push_back(vector_column);
  }
  io_.out(map);
}
