//------------------------------------------------------------------------------
// Game.h
//
// Group: Group 18622, study assistant Roman Walch
//
// Authors: Christina Dionysio (01610877)
// Johannes Mayerhofer (11739820)
// Robert Ertl (01114419)
//------------------------------------------------------------------------------
//

#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

#include <string>
#include <vector>
#include <memory>
#include <algorithm>

#include "Field.h"
#include "Grass.h"
#include "Street.h"
#include "Water.h"
#include "Obstacle.h"
#include "Home.h"
#include "Townhall.h"
#include "Clinic.h"
#include "Market.h"
#include "Interface.h"

namespace Sep
{

	//----------------------------------------------------------------------------
	// Game Class
	// class with the game logic
	//
	class Game
	{
	private:

		//--------------------------------------------------------------------------
		// Attribute for the board width
		//
		int board_width_;

		//--------------------------------------------------------------------------
		// Attribute for the board height
		//
		int board_height_;

		//--------------------------------------------------------------------------
		// Attribute for the ingame money
		//
		int money_;

		//--------------------------------------------------------------------------
		// Attribute for the game interface
		//
		Interface & io_;

		//--------------------------------------------------------------------------
		// Attribute for the game config
		//
		std::string config_;

		//--------------------------------------------------------------------------
		// Attribute for the Board of the game
		//
		std::vector<std::vector<std::shared_ptr<Field>>> map_;

	public:

		//--------------------------------------------------------------------------
		// Constant to grass field
		//
		static const std::shared_ptr<Field> GRASSPTR;

		//--------------------------------------------------------------------------
		// Constant to obstacle field
		//
		static const std::shared_ptr<Field> OBSTACLEPTR;

		//--------------------------------------------------------------------------
		// Constant to water field
		//
		static const std::shared_ptr<Field> WATERPTR;

		//--------------------------------------------------------------------------
		// Constructor
		// @param io referenze to interface
    // @param config contains the configfilename
    //
		Game(Interface &io, std::string config);

		//--------------------------------------------------------------------------
		// Deleted copy constructor
		//
		Game(const Game& original) = delete;

		//--------------------------------------------------------------------------
		// Deleted assignment operator
		//
		Game& operator=(const Game& original) = delete;

		//--------------------------------------------------------------------------
		// Destructor
		//
		virtual ~Game() noexcept;

		//--------------------------------------------------------------------------
		// Getter
		//
		int getWidth();
		int getHeight();
		int getMoney();
		std::vector<std::vector<std::shared_ptr<Field>>> getMap();

		//--------------------------------------------------------------------------
		// Setter
		//
		void setWidth(const int width);
		void setHeight(const int height);
		void setMoney(const int money);
		void setMap(const std::vector<std::shared_ptr<Field>> column_vec);


		//--------------------------------------------------------------------------
		// Method to start the game logic
		//
		void run();

		//--------------------------------------------------------------------------
		// Method to build the Field fieldType at position (x, y)
		// @param field_type contains the corresponding Field enum type
    // @param x contains x coordinates
    // @param y contains y coordinates
    //
		void build(Field::FieldType field_type, int x, int y);

		//--------------------------------------------------------------------------
		// Method to build the Field fieldType at position (x, y)
    // with the size width*height
    // @param field_type contains the corresponding Field enum type
    // @param x contains x coordinates
    // @param y contains y coordinates
    // @param width contains the width of the fieldtype
    // @param height contains the height of the fieldtype
    //
		void build(Field::FieldType field_type, int x, int y, int width, int height);

		//--------------------------------------------------------------------------
		// Method to destroy the field at position (x, y)
		// @param x contains x coordinates
    // @param y contains y coordinates
    //
		void destroy(int x, int y);

		//--------------------------------------------------------------------------
		// Method to run the game logic before the game quits
		//
		void quit();

		//--------------------------------------------------------------------------
		// Method to check if the position is near any building
    // @param x contains x coordinates
    // @param y contains y coordinates
    // @param width contains the width of the field
    // @param height contains the height of the field
    // @return returns if it has neightbours true or false
    //
		bool hasNeighbour(int x, int y, int width, int height);

		//--------------------------------------------------------------------------
		// Method to set a Field in the Map
    // @param fieldType contains the corresponding Field
    // @param x contains x coordinates
    // @param y contains y coordinates
    // @param width contains the width of the fieldtype
    // @param height contains the height of the fieldtype
    // @param is_building contains if buildable
    // @return returns if Field is set true or false
    //
		bool setField(std::shared_ptr<Field> field, int x, int y, int width = 1,
		        int height = 1, bool is_building = false);

		//--------------------------------------------------------------------------
		// Method to print the map
		//
		void printMap();
	};
}
#endif // GAME_H_INCLUDED