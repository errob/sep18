//------------------------------------------------------------------------------
// Home.cpp
//
// Group: Group 18622, study assistant Roman Walch
//
// Authors: Christina Dionysio (01610877)
// Johannes Mayerhofer (11739820)
// Robert Ertl (01114419)
//------------------------------------------------------------------------------
//
 
#include "Home.h"

using Sep::Home;
using Sep::Field;

//------------------------------------------------------------------------------
Home::Home(const int pos_x, const int pos_y, const int width, const int height)
        : Building(FieldType::HOME, "H", true, true, 100, 100, pos_x, pos_y, 
                   width, height)
{
}

//------------------------------------------------------------------------------
Home::~Home() noexcept
{
}


