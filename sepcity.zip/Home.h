//------------------------------------------------------------------------------
// Home.h
//
// Group: Group 18622, study assistant Roman Walch
//
// Authors: Christina Dionysio (01610877)
// Johannes Mayerhofer (11739820)
// Robert Ertl (01114419)
//------------------------------------------------------------------------------
//

#ifndef HOME_H_INCLUDED
#define HOME_H_INCLUDED

#include "Building.h"

namespace Sep
{
  //----------------------------------------------------------------------------
  // Home Class
  // class to create field of type home 
  //
  class Home : public Building
  {
    public:

      //------------------------------------------------------------------------
      // Standard constructor
      // @param pos_x contains x coordinates of home
      // @param pos_y contains y coordinates of home
      // @param width contains width of home
      // @param height contains height of home
      //
      Home(const int pos_x, const int pos_y, const int width, const int height);

      //------------------------------------------------------------------------
      // Deleted copy constructor
      //
      Home (const Home& original) = delete;

      //------------------------------------------------------------------------
      // Deleted assignment operator
      //
      Home& operator=(const Home& original) = delete;

      //------------------------------------------------------------------------
      // Destructor
      //
      virtual ~Home() noexcept;
  };
}
#endif  // HOME_H_INCLUDED