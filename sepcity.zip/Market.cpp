//------------------------------------------------------------------------------
// Market.cpp
//
// Group: Group 18622, study assistant Roman Walch
//
// Authors: Christina Dionysio (01610877)
// Johannes Mayerhofer (11739820)
// Robert Ertl (01114419)
//------------------------------------------------------------------------------
//
 
#include "Market.h"

using Sep::Market;
using Sep::Field;

//------------------------------------------------------------------------------
Market::Market(const int pos_x, const int pos_y, const int width,
               const int height) : Building(FieldType::MARKET, "M", true, true, 
                                        150, 100, pos_x, pos_y, width, height)
{
}

//------------------------------------------------------------------------------
Market::~Market() noexcept
{
}


